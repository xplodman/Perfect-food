<?php
require_once 'classes/DB.php';
require_once 'classes/User.php';
require_once 'classes/Menu.php';
require_once 'classes/MenuItem.php';
require_once 'classes/Order.php';
require_once 'classes/Branch.php';
require_once 'classes/Reserve.php';
require_once 'classes/Evaluate.php';