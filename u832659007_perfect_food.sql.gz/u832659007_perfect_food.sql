-- MariaDB dump 10.19  Distrib 10.11.7-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u832659007_perfect_food
-- ------------------------------------------------------
-- Server version	10.11.7-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` time NOT NULL,
  `guests` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES
(3,16,2,'1986-08-01','15:02:00',619,'2024-04-11 18:42:55','completed'),
(4,16,3,'1974-07-27','21:54:00',18,'2024-04-11 19:19:11','in_progress'),
(5,16,2,'2014-12-20','05:03:00',291,'2024-04-11 19:19:13','completed'),
(6,16,3,'1987-06-03','04:55:00',409,'2024-04-11 23:01:12','cancelled'),
(7,16,4,'1985-06-21','19:02:00',812,'2024-04-11 23:24:37','in_progress'),
(8,17,2,'2024-04-16','23:40:00',20,'2024-04-12 19:38:59','completed'),
(9,16,5,'2023-08-14','20:44:00',148,'2024-04-13 20:22:54','pending'),
(10,16,3,'1990-03-10','06:14:00',432,'2024-04-13 20:23:23','pending'),
(11,16,5,'1976-09-11','03:50:00',822,'2024-04-13 20:23:27','pending'),
(12,16,3,'2000-05-30','09:44:00',173,'2024-04-13 20:23:58','pending'),
(13,16,2,'1979-12-29','03:03:00',614,'2024-04-13 20:24:14','pending'),
(14,16,1,'2008-05-12','18:06:00',693,'2024-04-14 10:05:58','cancelled'),
(15,16,4,'2024-04-16','17:43:00',13,'2024-04-16 15:44:12','pending'),
(16,16,2,'2024-04-30','21:20:00',11,'2024-04-17 16:19:42','pending'),
(19,16,4,'2024-05-10','15:32:00',55,'2024-04-23 19:25:49','pending'),
(20,16,5,'2024-04-28','20:30:00',23,'2024-04-23 19:26:22','pending'),
(21,16,4,'2024-05-06','13:29:00',26,'2024-04-23 19:26:48','pending'),
(22,16,4,'2024-04-26','17:00:00',10,'2024-04-24 11:57:08','pending'),
(23,16,1,'2024-04-26','16:00:00',15,'2024-04-24 11:57:32','pending'),
(24,16,2,'2024-05-01','15:00:00',5,'2024-04-24 11:57:54','pending'),
(25,16,1,'2024-05-13','00:32:00',20,'2024-05-12 21:33:30','pending'),
(26,16,1,'2024-05-13','01:04:00',20,'2024-05-12 22:04:37','pending'),
(27,16,1,'2024-05-13','01:04:00',20,'2024-05-12 22:05:40','pending'),
(28,16,5,'2024-05-13','14:16:00',50,'2024-05-13 11:16:53','pending'),
(29,16,3,'2024-05-30','23:08:00',30,'2024-05-13 16:09:10','completed'),
(30,16,1,'2024-05-20','08:23:00',60,'2024-05-13 16:23:12','completed'),
(31,16,3,'2024-05-14','12:05:00',80,'2024-05-14 09:06:02','pending'),
(32,16,1,'2024-05-14','18:25:00',50,'2024-05-14 15:25:38','pending'),
(33,16,1,'2024-05-21','00:05:00',100,'2024-05-20 21:05:49','pending'),
(34,16,1,'2024-05-21','00:05:00',100,'2024-05-20 21:06:50','pending');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `max_guests` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES
(1,'Cairo Central','13 El-Gomhoreya Street, Downtown, Cairo, Egypt','Phone: +20 12 3456 7890, Email: cairocentral@example.com',100),
(2,'Cairo East','5 Salah Salem Street, Nasr City, Cairo, Egypt','Phone: +20 12 3456 7891, Email: cairoeast@example.com',500),
(3,'Cairo West','10 El Haram Street, Giza, Cairo, Egypt','Phone: +20 12 3456 7892, Email: cairowest@example.com',52),
(4,'Cairo North','30 El Nozha Street, Heliopolis, Cairo, Egypt','Phone: +20 12 3456 7893, Email: caironorth@example.com',20),
(5,'Cairo South','25 Corniche El Nil, Maadi, Cairo, Egypt','Phone: +20 12 3456 7894, Email: cairosouth@example.com',5);
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluations`
--

DROP TABLE IF EXISTS `evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `evaluations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `evaluations_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `evaluations_ibfk_2` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluations`
--

LOCK TABLES `evaluations` WRITE;
/*!40000 ALTER TABLE `evaluations` DISABLE KEYS */;
INSERT INTO `evaluations` VALUES
(1,NULL,3,1,'Voluptas rem sapient','2024-04-12 20:53:50'),
(2,11,NULL,5,'Dolore ut temporibus','2024-04-12 21:04:25'),
(3,10,NULL,5,'cc','2024-04-13 20:14:41'),
(4,NULL,5,1,'it is very nice','2024-04-16 15:40:29'),
(5,15,NULL,5,'','2024-04-23 19:01:48'),
(6,32,NULL,3,'It\'s very nice','2024-05-12 12:15:58'),
(7,31,NULL,2,'acceptable','2024-05-12 12:19:30'),
(8,30,NULL,1,'','2024-05-12 16:49:37');
/*!40000 ALTER TABLE `evaluations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  CONSTRAINT `menu_items_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES
(1,'Classic Pancakes','Fluffy pancakes served with maple syrup','assets/images/1.jpg',9.99,1,1),
(2,'Avocado Toast','Sliced avocado on toasted bread with poached eggs','assets/images/2.jpeg',12.99,1,1),
(3,'Club Sandwich','Triple-decker sandwich with turkey, bacon, lettuce, and tomato','assets/images/3.jpg',11.99,2,1),
(4,'Caesar Salad','Romaine lettuce, croutons, Parmesan cheese, and Caesar dressing','assets/images/4.jpg',8.99,2,1),
(5,'Grilled Salmon','Fresh Atlantic salmon fillet grilled to perfection','assets/images/5.jpg',17.99,3,1),
(6,'Ribeye Steak','Juicy ribeye steak cooked to your liking','assets/images/6.jpg',24.99,3,1),
(7,'Iced Coffee','Chilled coffee served over ice with milk or cream','assets/images/7.jpg',4.99,4,1),
(8,'Fresh Orange Juice','Cold-pressed orange juice made from freshly squeezed oranges','assets/images/8.webp',3.99,4,1),
(9,'Chocolate Brownie','Rich and fudgy chocolate brownie topped with vanilla ice cream','assets/images/9.webp',6.99,5,1),
(10,'New York Cheesecake','Creamy cheesecake with a graham cracker crust','assets/images/10.jpg',7.99,5,1),
(11,'Mango Sorbet','Refreshing mango sorbet made with ripe mangoes','assets/images/11.jpg',5.99,5,1),
(12,'Quinoa Salad','Healthy salad with quinoa, mixed greens, and veggies','assets/images/12.jpeg',10.99,6,1),
(13,'Vegetable Stir-Fry','Assorted vegetables stir-fried in a savory sauce','assets/images/13.jpg',9.99,6,1),
(14,'Chicken Tenders','Breaded and fried chicken tenders served with dipping sauce','assets/images/14.jpg',6.99,7,1),
(15,'Macaroni and Cheese','Creamy macaroni pasta with melted cheese','assets/images/15.jpg',5.99,7,1),
(16,'Cheese Pizza','Classic cheese pizza with tomato sauce and mozzarella cheese','assets/images/16.webp',8.99,7,1);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES
(1,'Breakfast Menu','Delicious breakfast options to start your day',1),
(2,'Lunch Menu','Satisfying lunch options for a midday meal',1),
(3,'Dinner Menu','Delectable dinner options for a hearty meal',1),
(4,'Drinks Menu','Refreshing beverages to quench your thirst',1),
(5,'Dessert Menu','Indulgent treats to satisfy your sweet tooth',1),
(6,'Vegetarian Menu','Delicious plant-based options for vegetarians',1),
(7,'Kids Menu','Kid-friendly meals that are sure to please',1);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_ibfk_1` (`order_id`),
  KEY `order_items_ibfk_2` (`item_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES
(16,10,1,1),
(17,10,2,1),
(18,10,3,1),
(19,10,4,1),
(20,11,1,1),
(21,11,15,1),
(22,11,2,2),
(23,11,3,2),
(24,11,16,1),
(25,11,6,1),
(26,11,4,1),
(27,11,10,1),
(28,12,1,1),
(29,13,9,1),
(30,13,3,1),
(31,13,4,1),
(32,13,2,1),
(33,13,1,1),
(34,14,13,1),
(35,15,3,1),
(36,15,4,2),
(37,16,1,1),
(38,16,2,1),
(39,16,4,1),
(40,16,8,1),
(43,18,10,1),
(44,19,8,1),
(45,20,4,1),
(46,21,2,1),
(47,22,1,1),
(48,23,13,2),
(49,23,1,1),
(50,24,7,1),
(51,24,4,1),
(52,25,3,1),
(53,25,4,1),
(54,26,1,1),
(55,26,2,1),
(56,26,3,1),
(57,26,4,1),
(58,26,5,1),
(59,26,6,1),
(60,27,15,1),
(61,27,7,1),
(62,27,8,1),
(63,28,3,1),
(65,30,5,1),
(66,31,15,1),
(67,31,3,1),
(68,31,13,1),
(69,32,6,1),
(70,32,10,1),
(71,33,10,1),
(72,33,11,1);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `street` varchar(100) NOT NULL,
  `house_number` varchar(20) NOT NULL,
  `phone_1` varchar(20) NOT NULL,
  `phone_2` varchar(20) DEFAULT NULL,
  `phone_3` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(10,16,'Erin','Finley','hexi@testing-mail.com','Eius et quisquam ani','Ut quos eum error qu','370','+1 (338) 683-1141','+1 (623) 468-7946','+1 (935) 879-7977','2024-04-11 18:08:59','in_progress'),
(11,16,'Erin','Finley','hexi@testing-mail.com','Eius et quisquam ani','Ut quos eum error qu','370','+1 (338) 683-1141','+1 (623) 468-7946','+1 (935) 879-7977','2024-04-11 18:59:41','pending'),
(12,16,'Erin','Finley','hexi@testing-mail.com','Eius et quisquam ani','Ut quos eum error qu','370','+1 (338) 683-1141','+1 (623) 468-7946','+1 (935) 879-7977','2024-04-11 19:01:39','in_progress'),
(13,16,'Erin','Finley','hexi@testing-mail.com','Eius et quisquam ani','Ut quos eum error qu','370','+1 (338) 683-1141','+1 (623) 468-7946','+1 (935) 879-7977','2024-04-11 19:18:57','cancelled'),
(14,16,'Clayton','Duncan','hexi@testing-mail.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-04-11 23:02:01','cancelled'),
(15,16,'Clayton','Duncan','hexi@testing-mail.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-04-12 02:19:19','completed'),
(16,17,'Jeremy','Carpenter','pykat@testing-mail.com','Id consectetur dolo','Exercitation fuga O','310','+1 (374) 125-1132','+1 (785) 933-4578','+1 (952) 879-5332','2024-04-12 19:41:05','in_progress'),
(18,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-04-18 20:40:33','pending'),
(19,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-04-19 09:47:00','in_progress'),
(20,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-04-19 09:59:14','in_progress'),
(21,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-04-25 12:10:00','in_progress'),
(22,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-04-25 12:10:02','in_progress'),
(23,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-11 10:10:32','in_progress'),
(24,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-11 10:11:48','in_progress'),
(25,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-11 10:20:15','pending'),
(26,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-11 10:32:44','in_progress'),
(27,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-12 09:46:04','pending'),
(28,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-12 09:46:28','pending'),
(29,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-12 09:52:01','completed'),
(30,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-12 10:31:47','completed'),
(31,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-12 10:46:50','completed'),
(32,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-12 10:50:18','completed'),
(33,16,'Clayton','Duncan','customer@perfect-food.com','Magni cupidatat sequ','Provident a reicien','889','+1 (951) 904-4956','+1 (579) 847-7154','+1 (807) 544-9348','2024-05-12 17:55:41','pending');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phones`
--

DROP TABLE IF EXISTS `phones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `phones_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phones`
--

LOCK TABLES `phones` WRITE;
/*!40000 ALTER TABLE `phones` DISABLE KEYS */;
INSERT INTO `phones` VALUES
(157,17,'01027906696'),
(158,17,'01027906696'),
(159,17,'01027906696'),
(160,16,'01027906696'),
(161,16,'01027906696'),
(162,16,'01027906696'),
(163,18,'01027906696'),
(164,18,'01027906696'),
(165,18,'01027906696'),
(166,19,'01027906696'),
(167,19,'01027906696'),
(168,19,'01027906696');
/*!40000 ALTER TABLE `phones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `street` varchar(100) NOT NULL,
  `house_number` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(16,'customer','Clayton','Duncan','customer@perfect-food.com','$2y$10$XOWEqR4H50n.Caplzd8HmumSqooRUIJE9jjIHWaD/7fg9AheN0Z5S','Magni cupidatat sequ','Provident a reicien','889','2024-04-11 15:37:17'),
(17,'admin','Jeremy','Carpenter','admin@perfect-food.com','$2y$10$XOWEqR4H50n.Caplzd8HmumSqooRUIJE9jjIHWaD/7fg9AheN0Z5S','Id consectetur dolo','Exercitation fuga O','310','2024-04-12 19:36:04'),
(18,'branch_manager','Josef','jony','branch-manager@perfect-food.com','$2y$10$XOWEqR4H50n.Caplzd8HmumSqooRUIJE9jjIHWaD/7fg9AheN0Z5S','Rome','pdngdsgtd','12863','2024-05-11 10:04:52'),
(19,'branch_manager','kolin','para','branch_manager@perfect-food.com','$2y$10$XOWEqR4H50n.Caplzd8HmumSqooRUIJE9jjIHWaD/7fg9AheN0Z5S','gfdre','hgyt','235','2024-05-11 10:18:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-21  9:46:07
